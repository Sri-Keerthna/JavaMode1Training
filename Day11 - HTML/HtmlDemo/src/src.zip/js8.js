/**
 * 
 */
function gotCursor(){
	//alert("Cursor Placed");
	frmData.firstName.value="";
}
function lostCursor(){
	alert("Cursor Left Current Control");
	frmData.lastName.value="Keerthna";
}