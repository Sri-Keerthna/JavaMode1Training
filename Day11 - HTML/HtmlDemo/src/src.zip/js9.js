/**
 * 
 */
function lostCursor(){
	var fname=frmData.firstName.value;
	var lname=frmData.lastName.value;
	var fullName=fname+lname;
	frmData.FullName.value=fullName;
}