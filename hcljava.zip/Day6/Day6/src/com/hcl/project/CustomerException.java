package com.hcl.project;

public class CustomerException extends 	Exception {
	public CustomerException(String error) {
		super(error);
}
}
