package com.hcl.collections;

import java.util.ArrayList;
import java.util.List;

public class GenEmploy {
  /**
* The main entry point.
* @param args has the args
*/
  public static void main(String[] args) {
    List<Employ> lstemploy = new ArrayList<Employ>();
    lstemploy.add(new Employ(1, "sri", 65465));
    lstemploy.add(new Employ(2, "keerthi", 87645));
    lstemploy.add(new Employ(6, "visha", 82347));
    lstemploy.add(new Employ(4, "nivi", 59839));
    System.out.println("Employ list");
    lstemploy.forEach(System.out::println);
  }
}
