package com.hcl.collections;

import java.util.ArrayList;
import java.util.List;

public class GenListInt {
  /**
* The main entry point.
* @param args has the args
*/
  public static void main(String[] args) {
    List<Integer> lstdata = new ArrayList<Integer>();
    lstdata.add(new Integer(42));
    lstdata.add(new Integer(32));
    lstdata.add(new Integer(45));
    lstdata.add(new Integer(56));
    int sum = 0;
    for (Integer i : lstdata) {
      sum += 1;
    }
    System.out.println("sum is " + sum);
  }
}
