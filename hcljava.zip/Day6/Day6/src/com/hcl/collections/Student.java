package com.hcl.collections;

public class Student {

	String fname;
	String lname;
	String city;
	double cgp;
	public Student(String fname, String lname, String city, double cgp) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.city = city;
		this.cgp = cgp;
	}
	@Override
	public String toString() {
		return "Student [fname=" + fname + ", lname=" + lname + ", city=" + city + ", cgp=" + cgp + "]";
	}
	
}
