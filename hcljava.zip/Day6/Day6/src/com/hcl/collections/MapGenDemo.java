package com.hcl.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapGenDemo {
public static void main(String[] args) {
	Map<Integer, String> m=new HashMap<Integer,String>();
	m.put(1, "dharshini");
	m.put(2, "babbar");
	m.put(3, "keerthi");
	m.put(4, "lakshmi");
	
	int key;
	String result;
	System.out.println("enter key ");
	Scanner sc=new Scanner(System.in);
	key=sc.nextInt();
	result=m.getOrDefault(key, "not found");
	System.out.println(result);
}
}
